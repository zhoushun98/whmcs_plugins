<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use WHMCS\Database\Capsule;

function self_renew_config()
{
    return [
        'name' => '自助续费',
        'description' => '客户可在客户区域自助查看到期产品并完成续费支付',
        'version' => '1.0.0',
        'author' => 'SelfRenew',
        'language' => 'chinese',
        'fields' => [
            'remind_days' => [
                'FriendlyName' => '提前提醒天数',
                'Type' => 'text',
                'Size' => '10',
                'Default' => '30',
                'Description' => '产品到期前多少天开始显示在续费列表中',
            ],
            'allow_credit' => [
                'FriendlyName' => '允许余额支付',
                'Type' => 'yesno',
                'Default' => 'on',
                'Description' => '勾选后客户可使用账户余额支付续费',
            ],
            'auto_apply_credit' => [
                'FriendlyName' => '自动应用余额',
                'Type' => 'yesno',
                'Default' => '',
                'Description' => '余额支付时自动将余额应用到发票',
            ],
        ],
    ];
}

function self_renew_activate()
{
    try {
        if (!Capsule::schema()->hasTable('mod_self_renew_logs')) {
            Capsule::schema()->create('mod_self_renew_logs', function ($table) {
                $table->increments('id');
                $table->integer('user_id')->index();
                $table->string('item_type', 20);
                $table->integer('item_id');
                $table->integer('invoice_id')->nullable();
                $table->decimal('amount', 10, 2)->default(0);
                $table->string('cycle', 20)->default('');
                $table->string('payment_method', 50)->default('');
                $table->string('status', 20)->default('pending');
                $table->timestamp('created_at')->useCurrent();
            });
        }
        return ['status' => 'success', 'description' => '自助续费模块激活成功'];
    } catch (\Exception $e) {
        return ['status' => 'error', 'description' => '激活失败: ' . $e->getMessage()];
    }
}

function self_renew_deactivate()
{
    try {
        Capsule::schema()->dropIfExists('mod_self_renew_logs');
        return ['status' => 'success', 'description' => '自助续费模块已停用，日志表已删除'];
    } catch (\Exception $e) {
        return ['status' => 'error', 'description' => '停用失败: ' . $e->getMessage()];
    }
}

/**
 * Admin area output
 */
function self_renew_output($vars)
{
    $modulelink = $vars['modulelink'];
    $action = isset($_GET['action']) ? $_GET['action'] : 'list';

    if ($action === 'clear_logs' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        Capsule::table('mod_self_renew_logs')->truncate();
        echo '<div class="alert alert-success">续费记录已清空。</div>';
    }

    $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
    $perPage = 20;
    $offset = ($page - 1) * $perPage;

    $totalLogs = Capsule::table('mod_self_renew_logs')->count();
    $totalAmount = Capsule::table('mod_self_renew_logs')->where('status', 'paid')->sum('amount');
    $totalPaid = Capsule::table('mod_self_renew_logs')->where('status', 'paid')->count();

    $logs = Capsule::table('mod_self_renew_logs as l')
        ->leftJoin('tblclients as c', 'l.user_id', '=', 'c.id')
        ->select(
            'l.*',
            Capsule::raw("CONCAT(c.firstname, ' ', c.lastname) as client_name"),
            'c.email as client_email'
        )
        ->orderBy('l.created_at', 'desc')
        ->offset($offset)
        ->limit($perPage)
        ->get();

    $totalPages = ceil($totalLogs / $perPage);

    $statusLabels = [
        'pending' => '<span class="label label-warning">待支付</span>',
        'paid' => '<span class="label label-success">已支付</span>',
        'cancelled' => '<span class="label label-danger">已取消</span>',
    ];

    $cycleLabels = [
        'monthly' => '月付',
        'quarterly' => '季付',
        'semiannually' => '半年付',
        'annually' => '年付',
        'biennially' => '两年付',
        'triennially' => '三年付',
    ];

    echo '<div class="row">';
    echo '<div class="col-sm-4"><div class="panel panel-default"><div class="panel-body text-center">';
    echo '<h3>' . $totalLogs . '</h3><p>总续费次数</p></div></div></div>';
    echo '<div class="col-sm-4"><div class="panel panel-default"><div class="panel-body text-center">';
    echo '<h3>' . $totalPaid . '</h3><p>已支付次数</p></div></div></div>';
    echo '<div class="col-sm-4"><div class="panel panel-default"><div class="panel-body text-center">';
    echo '<h3>' . number_format($totalAmount, 2) . '</h3><p>已支付总金额</p></div></div></div>';
    echo '</div>';

    echo '<div class="panel panel-default">';
    echo '<div class="panel-heading clearfix"><h3 class="panel-title pull-left">续费记录</h3>';
    echo '<form method="post" action="' . $modulelink . '&action=clear_logs" class="pull-right" style="margin:0;" onsubmit="return confirm(\'确认清空所有续费记录？此操作不可恢复！\');">';
    echo '<button type="submit" class="btn btn-danger btn-xs"><i class="fas fa-trash"></i> 清空记录</button>';
    echo '</form></div>';
    echo '<div class="panel-body table-responsive">';
    echo '<table class="table table-striped table-bordered">';
    echo '<thead><tr>';
    echo '<th>ID</th><th>客户</th><th>类型</th><th>项目ID</th><th>发票ID</th>';
    echo '<th>金额</th><th>周期</th><th>支付方式</th><th>状态</th><th>时间</th>';
    echo '</tr></thead><tbody>';

    foreach ($logs as $log) {
        $type = '产品/服务';
        $status = isset($statusLabels[$log->status]) ? $statusLabels[$log->status] : $log->status;
        $cycle = isset($cycleLabels[$log->cycle]) ? $cycleLabels[$log->cycle] : $log->cycle;
        $invoiceLink = $log->invoice_id
            ? '<a href="invoices.php?action=edit&id=' . $log->invoice_id . '">#' . $log->invoice_id . '</a>'
            : '-';

        echo '<tr>';
        echo '<td>' . $log->id . '</td>';
        echo '<td>' . htmlspecialchars($log->client_name) . '<br><small>' . htmlspecialchars($log->client_email) . '</small></td>';
        echo '<td>' . $type . '</td>';
        echo '<td>' . $log->item_id . '</td>';
        echo '<td>' . $invoiceLink . '</td>';
        echo '<td>' . number_format($log->amount, 2) . '</td>';
        echo '<td>' . $cycle . '</td>';
        echo '<td>' . htmlspecialchars($log->payment_method) . '</td>';
        echo '<td>' . $status . '</td>';
        echo '<td>' . $log->created_at . '</td>';
        echo '</tr>';
    }

    if (count($logs) === 0) {
        echo '<tr><td colspan="10" class="text-center">暂无续费记录</td></tr>';
    }

    echo '</tbody></table>';

    if ($totalPages > 1) {
        echo '<nav><ul class="pagination">';
        for ($i = 1; $i <= $totalPages; $i++) {
            $active = $i === $page ? ' class="active"' : '';
            echo '<li' . $active . '><a href="' . $modulelink . '&page=' . $i . '">' . $i . '</a></li>';
        }
        echo '</ul></nav>';
    }

    echo '</div></div>';
}

/**
 * Client area output
 */
function self_renew_clientarea($vars)
{
    $modulelink = $vars['modulelink'];
    $LANG = $vars['_lang'];
    $action = isset($_GET['a']) ? $_GET['a'] : 'home';
    $remindDays = (int)$vars['remind_days'] ?: 30;
    $allowCredit = $vars['allow_credit'] === 'on';
    $autoApplyCredit = $vars['auto_apply_credit'] === 'on';

    $client = self_renew_getCurrentClient();
    if (!$client) {
        return [
            'pagetitle' => $LANG['page_title'] ?? '自助续费',
            'breadcrumb' => ['index.php?m=self_renew' => $LANG['page_title'] ?? '自助续费'],
            'templatefile' => 'clienthome',
            'requirelogin' => true,
            'vars' => ['error' => $LANG['login_required'] ?? '请先登录'],
        ];
    }

    if ($action === 'renew' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        return self_renew_handleRenew($client, $vars, $modulelink, $LANG);
    }

    $cutoffDate = date('Y-m-d', strtotime("+{$remindDays} days"));

    $hostings = Capsule::table('tblhosting as h')
        ->join('tblproducts as p', 'h.packageid', '=', 'p.id')
        ->where('h.userid', $client->id)
        ->whereIn('h.domainstatus', ['Active', 'Suspended'])
        ->where('h.billingcycle', '!=', 'Free Account')
        ->where('h.billingcycle', '!=', 'One Time')
        ->select('h.id', 'h.domain', 'h.packageid', 'h.billingcycle', 'h.amount', 'h.nextduedate', 'p.name as product_name', 'p.paytype')
        ->orderBy('h.nextduedate', 'asc')
        ->get();

    foreach ($hostings as &$h) {
        $h->cycles = self_renew_getProductCycles($h->packageid, $client->currency);
        $h->days_left = (int)((strtotime($h->nextduedate) - time()) / 86400);
    }
    unset($h);

    $gateways = self_renew_getActiveGateways();

    $currencyData = Capsule::table('tblcurrencies')->where('id', $client->currency)->first();

    return [
        'pagetitle' => $LANG['page_title'] ?? '自助续费',
        'breadcrumb' => ['index.php?m=self_renew' => $LANG['page_title'] ?? '自助续费'],
        'templatefile' => 'clienthome',
        'requirelogin' => true,
        'vars' => [
            'modulelink' => $modulelink,
            'hostings' => $hostings,
            'gateways' => $gateways,
            'allow_credit' => $allowCredit,
            'credit_gateway' => $client->defaultgateway ?: '',
            'client' => $client,
            'currency' => $currencyData,
            'remind_days' => $remindDays,
            'success' => isset($_GET['success']) ? ($LANG['renew_success'] ?? '续费发票已生成') : '',
            'invoice_id' => isset($_GET['invoice_id']) ? (int)$_GET['invoice_id'] : 0,
            'error' => isset($_GET['error']) ? urldecode($_GET['error']) : '',
            'lang' => $LANG,
        ],
    ];
}

// --- Helper Functions ---

function self_renew_getCurrentClient()
{
    $uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
    if (!$uid) {
        return null;
    }
    return Capsule::table('tblclients')->where('id', $uid)->first();
}

function self_renew_getProductCycles($productId, $currencyId)
{
    $pricing = Capsule::table('tblpricing')
        ->where('type', 'product')
        ->where('relid', $productId)
        ->where('currency', $currencyId)
        ->first();

    if (!$pricing) {
        return [];
    }

    $cycleMap = [
        'monthly' => ['field' => 'monthly', 'label' => '月付', 'months' => 1],
        'quarterly' => ['field' => 'quarterly', 'label' => '季付', 'months' => 3],
        'semiannually' => ['field' => 'semiannually', 'label' => '半年付', 'months' => 6],
        'annually' => ['field' => 'annually', 'label' => '年付', 'months' => 12],
        'biennially' => ['field' => 'biennially', 'label' => '两年付', 'months' => 24],
        'triennially' => ['field' => 'triennially', 'label' => '三年付', 'months' => 36],
    ];

    $cycles = [];
    foreach ($cycleMap as $key => $info) {
        $price = (float)$pricing->{$info['field']};
        if ($price >= 0) {
            $cycles[$key] = [
                'label' => $info['label'],
                'price' => $price,
                'months' => $info['months'],
            ];
        }
    }

    return $cycles;
}

function self_renew_getActiveGateways()
{
    $visible = Capsule::table('tblpaymentgateways')
        ->where('setting', 'visible')
        ->where('value', 'on')
        ->pluck('gateway');

    $gateways = [];
    foreach ($visible as $gw) {
        $nameRow = Capsule::table('tblpaymentgateways')
            ->where('gateway', $gw)
            ->where('setting', 'name')
            ->first();
        $gateways[$gw] = $nameRow ? $nameRow->value : $gw;
    }
    return $gateways;
}

function self_renew_handleRenew($client, $vars, $modulelink, $LANG)
{
    $allowCredit = $vars['allow_credit'] === 'on';
    $autoApplyCredit = $vars['auto_apply_credit'] === 'on';

    $selectedHostings = isset($_POST['hosting']) ? (array)$_POST['hosting'] : [];
    $paymentMethod = isset($_POST['payment_method']) ? $_POST['payment_method'] : '';
    $useCredit = isset($_POST['use_credit']) && $_POST['use_credit'] === '1';

    if (empty($selectedHostings)) {
        header("Location: {$modulelink}&error=" . urlencode($LANG['no_items_selected'] ?? '请选择至少一个续费项目'));
        exit;
    }

    if (empty($paymentMethod)) {
        if (!$useCredit || !$allowCredit || (float)$client->credit <= 0) {
            header("Location: {$modulelink}&error=" . urlencode($LANG['no_payment_selected'] ?? '请选择支付方式'));
            exit;
        }
        $firstGw = Capsule::table('tblpaymentgateways')
            ->where('setting', 'visible')->where('value', 'on')->value('gateway');
        $paymentMethod = $client->defaultgateway ?: ($firstGw ?: 'mailin');
    }

    $invoiceItems = [];
    $logEntries = [];
    $totalAmount = 0;

    foreach ($selectedHostings as $hostingId => $cycle) {
        if (empty($cycle)) continue;

        $hosting = Capsule::table('tblhosting')
            ->where('id', (int)$hostingId)
            ->where('userid', $client->id)
            ->first();

        if (!$hosting) continue;

        $cycles = self_renew_getProductCycles($hosting->packageid, $client->currency);
        if (!isset($cycles[$cycle])) continue;

        $price = $cycles[$cycle]['price'];
        $product = Capsule::table('tblproducts')->where('id', $hosting->packageid)->first();
        $productName = $product ? $product->name : 'Product #' . $hosting->packageid;

        $description = $productName;
        if ($hosting->domain) {
            $description .= ' - ' . $hosting->domain;
        }
        $description .= ' (' . $cycles[$cycle]['label'] . ')';

        $invoiceItems[] = [
            'description' => $description,
            'amount' => $price,
            'taxed' => true,
        ];

        $logEntries[] = [
            'item_type' => 'hosting',
            'item_id' => (int)$hostingId,
            'amount' => $price,
            'cycle' => $cycle,
        ];

        $totalAmount += $price;
    }

    if (empty($invoiceItems)) {
        header("Location: {$modulelink}&error=" . urlencode($LANG['no_valid_items'] ?? '未找到有效的续费项目'));
        exit;
    }

    $applyCredit = ($useCredit && $allowCredit && (float)$client->credit > 0) ? '1' : '0';

    $invoiceData = [
        'userid' => $client->id,
        'status' => 'Unpaid',
        'sendinvoice' => '0',
        'paymentmethod' => $paymentMethod,
        'date' => date('Y-m-d'),
        'duedate' => date('Y-m-d'),
        'autoapplycredit' => $applyCredit,
    ];

    foreach ($invoiceItems as $i => $item) {
        $n = $i + 1;
        $invoiceData["itemdescription{$n}"] = $item['description'];
        $invoiceData["itemamount{$n}"] = $item['amount'];
        $invoiceData["itemtaxed{$n}"] = $item['taxed'] ? '1' : '0';
    }

    $result = localAPI('CreateInvoice', $invoiceData);

    if ($result['result'] !== 'success') {
        header("Location: {$modulelink}&error=" . urlencode($LANG['invoice_create_failed'] ?? '发票创建失败: ' . ($result['message'] ?? '')));
        exit;
    }

    $invoiceId = (int)$result['invoiceid'];

    $payLabel = $paymentMethod;
    if ($useCredit) {
        $payLabel = 'credit+' . $paymentMethod;
    }

    foreach ($logEntries as $entry) {
        Capsule::table('mod_self_renew_logs')->insert([
            'user_id' => $client->id,
            'item_type' => $entry['item_type'],
            'item_id' => $entry['item_id'],
            'invoice_id' => $invoiceId,
            'amount' => $entry['amount'],
            'cycle' => $entry['cycle'],
            'payment_method' => $payLabel,
            'status' => 'pending',
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }

    $invoice = Capsule::table('tblinvoices')->where('id', $invoiceId)->first();
    if ($invoice && $invoice->status === 'Paid') {
        Capsule::table('mod_self_renew_logs')
            ->where('invoice_id', $invoiceId)
            ->update(['status' => 'paid']);
        header("Location: {$modulelink}&success=1&invoice_id={$invoiceId}");
        exit;
    }

    header("Location: viewinvoice.php?id={$invoiceId}");
    exit;
}

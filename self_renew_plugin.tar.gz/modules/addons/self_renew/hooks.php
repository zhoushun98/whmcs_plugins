<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use WHMCS\View\Menu\Item as MenuItem;

add_hook('ClientAreaPrimarySidebar', 1, function (MenuItem $primarySidebar) {
    $serviceMenu = $primarySidebar->getChild('Service Details Overview');
    if (is_null($serviceMenu)) {
        $serviceMenu = $primarySidebar->getChild('My Account');
    }

    if (!is_null($serviceMenu)) {
        $serviceMenu->addChild('Self Renew', [
            'label' => '自助续费',
            'uri' => 'index.php?m=self_renew',
            'icon' => 'fas fa-sync-alt',
            'order' => 99,
        ]);
    }
});

add_hook('ClientAreaSecondarySidebar', 1, function (MenuItem $secondarySidebar) {
    if (isset($_GET['m']) && $_GET['m'] === 'self_renew') {
        $renewPanel = $secondarySidebar->addChild('Renew Info', [
            'label' => '续费说明',
            'icon' => 'fas fa-info-circle',
        ]);
        $renewPanel->setBodyHtml(
            '<p>选择需要续费的产品，选择续费周期后提交即可生成续费发票。</p>'
            . '<p>支持账户余额支付和在线支付网关。</p>'
        );
    }
});

add_hook('InvoicePaid', 1, function ($vars) {
    $invoiceId = $vars['invoiceid'];
    $db = \WHMCS\Database\Capsule::table('mod_self_renew_logs');

    $logs = $db->where('invoice_id', $invoiceId)
        ->where('status', 'pending')
        ->get();

    if ($logs->isEmpty()) {
        return;
    }

    $cycleMonths = [
        'monthly' => 1,
        'quarterly' => 3,
        'semiannually' => 6,
        'annually' => 12,
        'biennially' => 24,
        'triennially' => 36,
    ];

    $cycleToWhmcs = [
        'monthly' => 'Monthly',
        'quarterly' => 'Quarterly',
        'semiannually' => 'Semi-Annually',
        'annually' => 'Annually',
        'biennially' => 'Biennially',
        'triennially' => 'Triennially',
    ];

    foreach ($logs as $log) {
        if ($log->item_type === 'hosting') {
            $hosting = \WHMCS\Database\Capsule::table('tblhosting')
                ->where('id', $log->item_id)
                ->first();

            if (!$hosting) continue;

            $months = isset($cycleMonths[$log->cycle]) ? $cycleMonths[$log->cycle] : 0;
            if ($months > 0) {
                $baseDate = $hosting->nextduedate;
                if (strtotime($baseDate) < time()) {
                    $baseDate = date('Y-m-d');
                }
                $newDueDate = date('Y-m-d', strtotime($baseDate . " +{$months} months"));

                $updateData = ['nextduedate' => $newDueDate, 'nextinvoicedate' => $newDueDate];

                if (isset($cycleToWhmcs[$log->cycle])) {
                    $updateData['billingcycle'] = $cycleToWhmcs[$log->cycle];
                    $updateData['amount'] = $log->amount;
                }

                if ($hosting->domainstatus === 'Suspended') {
                    $updateData['domainstatus'] = 'Active';
                }

                \WHMCS\Database\Capsule::table('tblhosting')
                    ->where('id', $log->item_id)
                    ->update($updateData);
            }

        }
    }

    \WHMCS\Database\Capsule::table('mod_self_renew_logs')
        ->where('invoice_id', $invoiceId)
        ->where('status', 'pending')
        ->update(['status' => 'paid']);
});

add_hook('InvoiceCancelled', 1, function ($vars) {
    $invoiceId = $vars['invoiceid'];

    \WHMCS\Database\Capsule::table('mod_self_renew_logs')
        ->where('invoice_id', $invoiceId)
        ->where('status', 'pending')
        ->update(['status' => 'cancelled']);
});

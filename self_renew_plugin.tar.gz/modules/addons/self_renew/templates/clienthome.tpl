{if $error}
<div class="alert alert-danger">
    <i class="fas fa-exclamation-circle"></i> {$error}
</div>
{/if}

{if $success}
<div class="alert alert-success">
    <i class="fas fa-check-circle"></i> {$success}
    {if $invoice_id}
        - <a href="viewinvoice.php?id={$invoice_id}">{$lang.view_invoice|default:'查看发票'} #{$invoice_id}</a>
    {/if}
</div>
{/if}

<form method="post" action="{$modulelink}&a=renew" id="renewForm">

<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h4 class="mb-0"><i class="fas fa-server"></i> {$lang.hosting_services|default:'产品/服务'}</h4>
        <span class="badge badge-secondary">{$hostings|@count} {$lang.items|default:'项'}</span>
    </div>
    <div class="card-body p-0">
        {if $hostings|@count > 0}
        <div class="table-responsive">
            <table class="table table-hover mb-0" id="hostingTable">
                <thead class="thead-light">
                    <tr>
                        <th style="width:40px">
                            <input type="checkbox" id="checkAllHosting" title="{$lang.select_all|default:'全选'}">
                        </th>
                        <th>{$lang.product_name|default:'产品名称'}</th>
                        <th>{$lang.domain_label|default:'域名'}</th>
                        <th>{$lang.current_cycle|default:'当前周期'}</th>
                        <th>{$lang.current_price|default:'当前价格'}</th>
                        <th>{$lang.due_date|default:'到期日期'}</th>
                        <th>{$lang.days_left|default:'剩余天数'}</th>
                        <th style="min-width:160px">{$lang.renew_cycle|default:'续费周期'}</th>
                    </tr>
                </thead>
                <tbody>
                {foreach $hostings as $h}
                    <tr class="{if $h->days_left <= 0}table-danger{elseif $h->days_left <= 7}table-warning{elseif $h->days_left <= 30}table-info{/if}">
                        <td>
                            {if $h->cycles|@count > 0}
                            <input type="checkbox" class="hosting-check" data-id="{$h->id}">
                            {/if}
                        </td>
                        <td><strong>{$h->product_name}</strong></td>
                        <td>{$h->domain|default:'-'}</td>
                        <td>
                            {if $h->billingcycle == 'Monthly'}{$lang.monthly|default:'月付'}
                            {elseif $h->billingcycle == 'Quarterly'}{$lang.quarterly|default:'季付'}
                            {elseif $h->billingcycle == 'Semi-Annually'}{$lang.semiannually|default:'半年付'}
                            {elseif $h->billingcycle == 'Annually'}{$lang.annually|default:'年付'}
                            {elseif $h->billingcycle == 'Biennially'}{$lang.biennially|default:'两年付'}
                            {elseif $h->billingcycle == 'Triennially'}{$lang.triennially|default:'三年付'}
                            {else}{$h->billingcycle}{/if}
                        </td>
                        <td>{$currency->prefix}{$h->amount|number_format:2}{$currency->suffix}</td>
                        <td>{$h->nextduedate}</td>
                        <td>
                            {if $h->days_left <= 0}
                                <span class="badge badge-danger">{$lang.expired|default:'已过期'}</span>
                            {elseif $h->days_left <= 7}
                                <span class="badge badge-warning">{$h->days_left} {$lang.days|default:'天'}</span>
                            {else}
                                <span class="badge badge-info">{$h->days_left} {$lang.days|default:'天'}</span>
                            {/if}
                        </td>
                        <td>
                            {if $h->cycles|@count > 0}
                            <select name="hosting[{$h->id}]" class="form-control form-control-sm cycle-select" data-type="hosting" data-id="{$h->id}" disabled>
                                <option value="">{$lang.select_cycle|default:'-- 选择周期 --'}</option>
                                {foreach $h->cycles as $key => $cycle}
                                <option value="{$key}" data-price="{$cycle.price}"
                                    {if ($key == 'monthly' && $h->billingcycle == 'Monthly')
                                    || ($key == 'quarterly' && $h->billingcycle == 'Quarterly')
                                    || ($key == 'semiannually' && $h->billingcycle == 'Semi-Annually')
                                    || ($key == 'annually' && $h->billingcycle == 'Annually')
                                    || ($key == 'biennially' && $h->billingcycle == 'Biennially')
                                    || ($key == 'triennially' && $h->billingcycle == 'Triennially')}selected{/if}>
                                    {$cycle.label} - {$currency->prefix}{$cycle.price|number_format:2}{$currency->suffix}
                                </option>
                                {/foreach}
                            </select>
                            {else}
                                <span class="text-muted">{$lang.no_cycles|default:'无可用周期'}</span>
                            {/if}
                        </td>
                    </tr>
                {/foreach}
                </tbody>
            </table>
        </div>
        {else}
        <div class="p-4 text-center text-muted">
            <i class="fas fa-info-circle"></i> {$lang.no_hosting|default:'暂无可续费的产品/服务'}
        </div>
        {/if}
    </div>
</div>

<div class="card mb-4">
    <div class="card-header">
        <h4 class="mb-0"><i class="fas fa-cash-register"></i> {$lang.payment_section|default:'支付信息'}</h4>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    {if $allow_credit && $client->credit > 0}
                    <div class="alert alert-info py-2 px-3 mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="use_credit" name="use_credit" value="1">
                            <label class="form-check-label" for="use_credit">
                                <i class="fas fa-wallet"></i>
                                {$lang.use_credit_label|default:'使用账户余额抵扣'}
                                <strong class="text-success">{$currency->prefix}{$client->credit|number_format:2}{$currency->suffix}</strong>
                            </label>
                        </div>
                        <div id="creditHint" class="small mt-1 ml-4" style="display:none;"></div>
                    </div>
                    {/if}
                    <input type="hidden" id="clientCredit" value="{$client->credit}">

                    <div id="gatewaySection">
                        <label><strong>{$lang.payment_method|default:'支付方式'}</strong></label>
                        {foreach $gateways as $gwKey => $gwName}
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="radio" name="payment_method" id="pay_{$gwKey}" value="{$gwKey}"
                                {if $gwKey == $client->defaultgateway}checked{/if}>
                            <label class="form-check-label" for="pay_{$gwKey}">
                                <i class="fas fa-credit-card"></i> {$gwName}
                            </label>
                        </div>
                        {/foreach}
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card bg-light">
                    <div class="card-body text-center">
                        <h5>{$lang.total_amount|default:'续费总金额'}</h5>
                        <h2 class="text-primary" id="totalAmount">{$currency->prefix}0.00{$currency->suffix}</h2>
                        <p class="text-muted mb-0" id="selectedCount">
                            {$lang.selected_items|default:'已选择'} <span id="itemCount">0</span> {$lang.items|default:'项'}
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <hr>
        <div class="text-center">
            <button type="submit" class="btn btn-primary btn-lg" id="submitBtn" disabled>
                <i class="fas fa-shopping-cart"></i> {$lang.submit_renew|default:'提交续费'}
            </button>
        </div>
    </div>
</div>

</form>

<script>
{literal}
document.addEventListener('DOMContentLoaded', function() {
    var prefix = '{/literal}{$currency->prefix}{literal}';
    var suffix = '{/literal}{$currency->suffix}{literal}';
    var clientCredit = parseFloat(document.getElementById('clientCredit') ? document.getElementById('clientCredit').value : 0) || 0;
    var creditCheckbox = document.getElementById('use_credit');
    var creditHint = document.getElementById('creditHint');
    var gatewaySection = document.getElementById('gatewaySection');

    var payRadios = document.querySelectorAll('input[name="payment_method"]');
    if (payRadios.length > 0 && !document.querySelector('input[name="payment_method"]:checked')) {
        payRadios[0].checked = true;
    }

    function autoSelectFirstOption(sel) {
        if (!sel.value || sel.value === '') {
            for (var i = 0; i < sel.options.length; i++) {
                if (sel.options[i].value !== '') {
                    sel.selectedIndex = i;
                    break;
                }
            }
        }
    }

    function updateCreditHint(total) {
        if (!creditCheckbox || !creditHint) return;

        if (!creditCheckbox.checked || total <= 0) {
            creditHint.style.display = 'none';
            if (gatewaySection) gatewaySection.style.display = '';
            return;
        }

        if (clientCredit >= total) {
            creditHint.style.display = 'block';
            creditHint.className = 'small mt-1 ml-4 text-success';
            creditHint.textContent = '{/literal}{$lang.credit_enough|default:'余额充足，将直接从余额扣款'}{literal}';
            if (gatewaySection) gatewaySection.style.display = 'none';
        } else {
            var remaining = (total - clientCredit).toFixed(2);
            creditHint.style.display = 'block';
            creditHint.className = 'small mt-1 ml-4 text-info';
            creditHint.textContent = '{/literal}{$lang.credit_partial|default:'将从余额扣除'}{literal} ' + prefix + clientCredit.toFixed(2) + suffix + '{/literal}{$lang.credit_partial_mid|default:'，剩余'}{literal} ' + prefix + remaining + suffix + ' {/literal}{$lang.credit_partial_suffix|default:'通过下方支付方式支付'}{literal}';
            if (gatewaySection) gatewaySection.style.display = '';
        }
    }

    function recalculate() {
        var total = 0;
        var count = 0;

        document.querySelectorAll('.hosting-check:checked').forEach(function(cb) {
            var id = cb.getAttribute('data-id');
            var sel = document.querySelector('select[name="hosting[' + id + ']"]');
            if (sel && sel.value) {
                var opt = sel.options[sel.selectedIndex];
                var price = parseFloat(opt.getAttribute('data-price')) || 0;
                total += price;
                count++;
            }
        });

        document.getElementById('totalAmount').textContent = prefix + total.toFixed(2) + suffix;
        document.getElementById('itemCount').textContent = count;

        updateCreditHint(total);

        document.getElementById('submitBtn').disabled = (count === 0);
    }

    if (creditCheckbox) {
        creditCheckbox.addEventListener('change', recalculate);
    }

    document.querySelectorAll('.hosting-check').forEach(function(cb) {
        cb.addEventListener('change', function() {
            var id = this.getAttribute('data-id');
            var sel = document.querySelector('select[name="hosting[' + id + ']"]');
            if (sel) {
                sel.disabled = !this.checked;
                if (this.checked) {
                    autoSelectFirstOption(sel);
                } else {
                    sel.value = '';
                }
            }
            recalculate();
        });
    });

    document.getElementById('checkAllHosting').addEventListener('change', function() {
        var checked = this.checked;
        document.querySelectorAll('.hosting-check').forEach(function(cb) {
            cb.checked = checked;
            cb.dispatchEvent(new Event('change'));
        });
    });

    document.querySelectorAll('.cycle-select').forEach(function(sel) {
        sel.addEventListener('change', recalculate);
    });

    document.querySelectorAll('input[name="payment_method"]').forEach(function(radio) {
        radio.addEventListener('change', recalculate);
    });

    document.getElementById('renewForm').addEventListener('submit', function(e) {
        var count = parseInt(document.getElementById('itemCount').textContent);
        var payMethod = document.querySelector('input[name="payment_method"]:checked');

        if (count === 0) {
            e.preventDefault();
            alert('{/literal}{$lang.alert_no_items|default:'请选择至少一个续费项目'}{literal}');
            return;
        }
        if (!payMethod) {
            e.preventDefault();
            alert('{/literal}{$lang.alert_no_payment|default:'请选择支付方式'}{literal}');
            return;
        }

        document.getElementById('submitBtn').disabled = true;
        document.getElementById('submitBtn').innerHTML = '<i class="fas fa-spinner fa-spin"></i> {/literal}{$lang.processing|default:'处理中...'}{literal}';
    });
});
{/literal}
</script>

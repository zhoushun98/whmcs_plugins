<?php

$_ADDONLANG['page_title'] = 'Self-Service Renewal';
$_ADDONLANG['login_required'] = 'Please login first';

$_ADDONLANG['hosting_services'] = 'Products / Services';
$_ADDONLANG['domains_title'] = 'Domains';
$_ADDONLANG['items'] = 'items';
$_ADDONLANG['select_all'] = 'Select All';

$_ADDONLANG['product_name'] = 'Product Name';
$_ADDONLANG['domain_label'] = 'Domain';
$_ADDONLANG['registrar_label'] = 'Registrar';
$_ADDONLANG['current_cycle'] = 'Current Cycle';
$_ADDONLANG['current_price'] = 'Current Price';
$_ADDONLANG['due_date'] = 'Due Date';
$_ADDONLANG['expiry_date'] = 'Expiry Date';
$_ADDONLANG['days_left'] = 'Days Left';
$_ADDONLANG['renew_cycle'] = 'Renewal Cycle';
$_ADDONLANG['renew_period'] = 'Renewal Period';

$_ADDONLANG['monthly'] = 'Monthly';
$_ADDONLANG['quarterly'] = 'Quarterly';
$_ADDONLANG['semiannually'] = 'Semi-Annually';
$_ADDONLANG['annually'] = 'Annually';
$_ADDONLANG['biennially'] = 'Biennially';
$_ADDONLANG['triennially'] = 'Triennially';

$_ADDONLANG['expired'] = 'Expired';
$_ADDONLANG['days'] = 'days';
$_ADDONLANG['year_unit'] = ' year(s)';

$_ADDONLANG['select_cycle'] = '-- Select Cycle --';
$_ADDONLANG['select_period'] = '-- Select Period --';
$_ADDONLANG['no_cycles'] = 'No cycles available';
$_ADDONLANG['no_renew_price'] = 'No renewal pricing';
$_ADDONLANG['no_hosting'] = 'No products/services available for renewal';
$_ADDONLANG['no_domains'] = 'No domains available for renewal';

$_ADDONLANG['payment_section'] = 'Payment';
$_ADDONLANG['payment_method'] = 'Payment Method';
$_ADDONLANG['account_credit'] = 'Account Credit';
$_ADDONLANG['total_amount'] = 'Total Renewal Amount';
$_ADDONLANG['selected_items'] = 'Selected';
$_ADDONLANG['submit_renew'] = 'Submit Renewal';

$_ADDONLANG['view_invoice'] = 'View Invoice';
$_ADDONLANG['renew_success'] = 'Renewal invoice has been generated successfully';
$_ADDONLANG['domain_renew_prefix'] = 'Domain Renewal';

$_ADDONLANG['no_items_selected'] = 'Please select at least one item to renew';
$_ADDONLANG['credit_not_allowed'] = 'Credit payment is not enabled';
$_ADDONLANG['no_valid_items'] = 'No valid renewal items found';
$_ADDONLANG['invoice_create_failed'] = 'Failed to create invoice';

$_ADDONLANG['use_credit_label'] = 'Apply account credit';
$_ADDONLANG['credit_partial'] = 'Will deduct';
$_ADDONLANG['credit_partial_mid'] = ' from credit, remaining';
$_ADDONLANG['credit_partial_suffix'] = 'via payment gateway below';
$_ADDONLANG['credit_enough'] = 'Credit sufficient, will pay in full from balance';
$_ADDONLANG['no_payment_selected'] = 'Please select a payment method';

$_ADDONLANG['alert_no_items'] = 'Please select at least one item to renew';
$_ADDONLANG['alert_no_payment'] = 'Please select a payment method';
$_ADDONLANG['processing'] = 'Processing...';

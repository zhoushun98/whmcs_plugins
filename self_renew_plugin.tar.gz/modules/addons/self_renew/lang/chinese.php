<?php

$_ADDONLANG['page_title'] = '自助续费';
$_ADDONLANG['login_required'] = '请先登录';

$_ADDONLANG['hosting_services'] = '产品/服务';
$_ADDONLANG['domains_title'] = '域名';
$_ADDONLANG['items'] = '项';
$_ADDONLANG['select_all'] = '全选';

$_ADDONLANG['product_name'] = '产品名称';
$_ADDONLANG['domain_label'] = '域名';
$_ADDONLANG['registrar_label'] = '注册商';
$_ADDONLANG['current_cycle'] = '当前周期';
$_ADDONLANG['current_price'] = '当前价格';
$_ADDONLANG['due_date'] = '到期日期';
$_ADDONLANG['expiry_date'] = '过期日期';
$_ADDONLANG['days_left'] = '剩余天数';
$_ADDONLANG['renew_cycle'] = '续费周期';
$_ADDONLANG['renew_period'] = '续费年限';

$_ADDONLANG['monthly'] = '月付';
$_ADDONLANG['quarterly'] = '季付';
$_ADDONLANG['semiannually'] = '半年付';
$_ADDONLANG['annually'] = '年付';
$_ADDONLANG['biennially'] = '两年付';
$_ADDONLANG['triennially'] = '三年付';

$_ADDONLANG['expired'] = '已过期';
$_ADDONLANG['days'] = '天';
$_ADDONLANG['year_unit'] = '年';

$_ADDONLANG['select_cycle'] = '-- 选择周期 --';
$_ADDONLANG['select_period'] = '-- 选择年限 --';
$_ADDONLANG['no_cycles'] = '无可用周期';
$_ADDONLANG['no_renew_price'] = '无续费价格';
$_ADDONLANG['no_hosting'] = '暂无可续费的产品/服务';
$_ADDONLANG['no_domains'] = '暂无可续费的域名';

$_ADDONLANG['payment_section'] = '支付信息';
$_ADDONLANG['payment_method'] = '支付方式';
$_ADDONLANG['account_credit'] = '账户余额';
$_ADDONLANG['total_amount'] = '续费总金额';
$_ADDONLANG['selected_items'] = '已选择';
$_ADDONLANG['submit_renew'] = '提交续费';

$_ADDONLANG['view_invoice'] = '查看发票';
$_ADDONLANG['renew_success'] = '续费发票已生成成功';
$_ADDONLANG['domain_renew_prefix'] = '域名续费';

$_ADDONLANG['no_items_selected'] = '请选择至少一个续费项目';
$_ADDONLANG['credit_not_allowed'] = '不支持余额支付';
$_ADDONLANG['no_valid_items'] = '未找到有效的续费项目';
$_ADDONLANG['invoice_create_failed'] = '发票创建失败';

$_ADDONLANG['use_credit_label'] = '使用账户余额抵扣';
$_ADDONLANG['credit_partial'] = '将从余额扣除';
$_ADDONLANG['credit_partial_mid'] = '，剩余';
$_ADDONLANG['credit_partial_suffix'] = '通过下方支付方式支付';
$_ADDONLANG['credit_enough'] = '余额充足，将直接从余额扣款';
$_ADDONLANG['no_payment_selected'] = '请选择支付方式';

$_ADDONLANG['alert_no_items'] = '请选择至少一个续费项目';
$_ADDONLANG['alert_no_payment'] = '请选择支付方式';
$_ADDONLANG['processing'] = '处理中...';

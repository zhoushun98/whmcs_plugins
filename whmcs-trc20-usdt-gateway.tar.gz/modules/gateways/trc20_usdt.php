<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use WHMCS\Database\Capsule;

function trc20_usdt_MetaData()
{
    return [
        'DisplayName' => 'USDT-TRC20 (自托管)',
        'APIVersion' => '1.1',
        'DisableLocalCreditCardInput' => true,
        'TokenisedStorage' => false,
    ];
}

function trc20_usdt_config()
{
    trc20_usdt_ensureTable();

    return [
        'FriendlyName' => [
            'Type' => 'System',
            'Value' => 'USDT-TRC20 (自托管)',
        ],
        'wallet_address' => [
            'FriendlyName' => 'TRC20 收款地址',
            'Type' => 'text',
            'Size' => '42',
            'Default' => '',
            'Description' => '您的 TRON 钱包地址，以 T 开头',
        ],
        'trongrid_api_key' => [
            'FriendlyName' => 'TronGrid API Key',
            'Type' => 'password',
            'Size' => '50',
            'Default' => '',
            'Description' => '可选，防止 API 限流。在 trongrid.io 免费申请',
        ],
        'exchange_rate' => [
            'FriendlyName' => 'USD/USDT 汇率',
            'Type' => 'text',
            'Size' => '10',
            'Default' => '1.00',
            'Description' => 'USD 到 USDT 的汇率，默认 1.00',
        ],
        'payment_timeout' => [
            'FriendlyName' => '支付超时（分钟）',
            'Type' => 'text',
            'Size' => '5',
            'Default' => '30',
            'Description' => '支付页面倒计时时间，默认 30 分钟',
        ],
        'cron_secret' => [
            'FriendlyName' => 'Cron 密钥',
            'Type' => 'password',
            'Size' => '32',
            'Default' => '',
            'Description' => '用于 HTTP 方式调用 Cron 的验证密钥',
        ],
    ];
}

function trc20_usdt_link($params)
{
    $walletAddress = trim($params['wallet_address']);
    $exchangeRate = floatval($params['exchange_rate']) ?: 1.00;
    $timeout = intval($params['payment_timeout']) ?: 30;

    $invoiceId = $params['invoiceid'];
    $amount = floatval($params['amount']);
    $systemUrl = rtrim($params['systemurl'], '/');

    if (empty($walletAddress)) {
        return '<div class="alert alert-danger">错误：TRC20 收款地址未配置</div>';
    }

    if (!preg_match('/^T[A-Za-z0-9]{33}$/', $walletAddress)) {
        return '<div class="alert alert-danger">错误：TRC20 收款地址格式不正确</div>';
    }

    // Check for existing pending payment for this invoice
    $existing = Capsule::table('mod_trc20_usdt_payments')
        ->where('invoice_id', $invoiceId)
        ->where('status', 0)
        ->where('expires_at', '>', date('Y-m-d H:i:s'))
        ->first();

    if ($existing) {
        $payUrl = $systemUrl . '/modules/gateways/trc20_usdt/pay.php?token=' . $existing->token;
        return '<a href="' . htmlspecialchars($payUrl) . '" class="btn btn-success btn-block">使用 USDT-TRC20 支付</a>';
    }

    // Calculate USDT amount
    $baseUsdt = round($amount * $exchangeRate, 4);

    // Generate unique amount
    try {
        $uniqueAmount = trc20_usdt_generateUniqueAmount($baseUsdt, $walletAddress);
    } catch (\Exception $e) {
        logModuleCall('trc20_usdt', 'unique_amount_error', $invoiceId, $e->getMessage());
        return '<div class="alert alert-danger">错误：' . htmlspecialchars($e->getMessage()) . '</div>';
    }

    // Generate access token
    $token = bin2hex(random_bytes(32));

    // Get user ID from invoice
    $invoice = Capsule::table('tblinvoices')->where('id', $invoiceId)->first();
    $userId = $invoice ? $invoice->userid : 0;

    // Insert payment record
    $expiresAt = date('Y-m-d H:i:s', time() + $timeout * 60);

    Capsule::table('mod_trc20_usdt_payments')->insert([
        'invoice_id' => $invoiceId,
        'user_id' => $userId,
        'amount_cny' => $amount,
        'amount_usdt' => $uniqueAmount,
        'wallet_address' => $walletAddress,
        'token' => $token,
        'status' => 0,
        'expires_at' => $expiresAt,
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s'),
    ]);

    logModuleCall('trc20_usdt', 'create_payment', [
        'invoice_id' => $invoiceId,
        'amount_usd' => $amount,
        'amount_usdt' => $uniqueAmount,
        'expires_at' => $expiresAt,
    ], 'Payment record created');

    $payUrl = $systemUrl . '/modules/gateways/trc20_usdt/pay.php?token=' . $token;
    return '<a href="' . htmlspecialchars($payUrl) . '" class="btn btn-success btn-block">使用 USDT-TRC20 支付</a>';
}

function trc20_usdt_generateUniqueAmount($baseAmount, $walletAddress)
{
    $usedAmounts = Capsule::table('mod_trc20_usdt_payments')
        ->where('wallet_address', $walletAddress)
        ->where('status', 0)
        ->where('expires_at', '>', date('Y-m-d H:i:s'))
        ->pluck('amount_usdt')
        ->map(function ($v) {
            return number_format((float)$v, 6, '.', '');
        })
        ->flip()
        ->toArray();

    $suffixStart = 0.0001;
    $suffixMax = 0.9999;
    $step = 0.0001;

    $suffix = $suffixStart;
    while ($suffix <= $suffixMax) {
        $candidate = round($baseAmount + $suffix, 6);
        $candidateStr = number_format($candidate, 6, '.', '');
        if (!isset($usedAmounts[$candidateStr])) {
            return $candidateStr;
        }
        $suffix = round($suffix + $step, 4);
    }

    throw new \Exception('无法生成唯一支付金额，当前待付订单过多，请稍后再试');
}

function trc20_usdt_ensureTable()
{
    if (!Capsule::schema()->hasTable('mod_trc20_usdt_payments')) {
        Capsule::schema()->create('mod_trc20_usdt_payments', function ($table) {
            $table->increments('id');
            $table->unsignedInteger('invoice_id');
            $table->unsignedInteger('user_id');
            $table->decimal('amount_cny', 16, 2);
            $table->decimal('amount_usdt', 16, 6);
            $table->string('wallet_address', 42);
            $table->string('token', 64)->unique();
            $table->tinyInteger('status')->default(0);
            $table->string('txid', 66)->nullable();
            $table->decimal('actual_amount', 16, 6)->nullable();
            $table->dateTime('expires_at');
            $table->dateTime('created_at');
            $table->dateTime('updated_at');
            $table->dateTime('paid_at')->nullable();
            $table->index('invoice_id');
            $table->index(['status', 'expires_at']);
            $table->index('txid');
        });
    }
}

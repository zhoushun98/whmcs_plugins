<?php
define("WHMCS", true);

require_once __DIR__ . '/../../../init.php';

use WHMCS\Database\Capsule;

$token = isset($_GET['token']) ? preg_replace('/[^a-f0-9]/', '', $_GET['token']) : '';

if (empty($token) || strlen($token) !== 64) {
    die('无效的支付链接');
}

$payment = Capsule::table('mod_trc20_usdt_payments')->where('token', $token)->first();

if (!$payment) {
    die('支付记录不存在');
}

$isExpired = $payment->status == 2 || (strtotime($payment->expires_at) < time() && $payment->status == 0);
$isPaid = $payment->status == 1;

$remainingSeconds = max(0, strtotime($payment->expires_at) - time());

$systemUrl = \WHMCS\Config\Setting::getValue('SystemURL');
$systemUrl = rtrim($systemUrl, '/');

$qrcodeUrl = $systemUrl . '/modules/gateways/trc20_usdt/qrcode.php?data=' . urlencode($payment->wallet_address);
$checkUrl = $systemUrl . '/modules/gateways/callback/trc20_usdt.php?action=check_status&token=' . urlencode($token);
$invoiceUrl = $systemUrl . '/viewinvoice.php?id=' . $payment->invoice_id;
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>USDT 支付 - #<?php echo (int)$payment->invoice_id; ?></title>
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
body{
    font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,"Noto Sans",sans-serif;
    font-size:14px;line-height:1.5;color:#212529;
    background:#f8f9fa;
    min-height:100vh;
    display:flex;justify-content:center;
    padding:40px 15px;
}
.wrap{width:100%;max-width:420px}
.card{background:#fff;border:1px solid rgba(0,0,0,.125);border-radius:.25rem;overflow:hidden}
.card-header{
    background:#336699;
    color:#fff;
    padding:.75rem 1.25rem;
    display:flex;justify-content:space-between;align-items:center;
}
.card-header h1{font-size:15px;font-weight:600;margin:0}
.card-header .badge{
    font-size:11px;font-weight:400;
    background:rgba(255,255,255,.2);
    padding:2px 8px;border-radius:.2rem;
}
.card-body{padding:1.25rem}
.card-footer{
    background:rgba(0,0,0,.03);
    border-top:1px solid rgba(0,0,0,.125);
    padding:0;
}
.card-footer a{
    display:block;text-align:center;
    padding:.6rem;font-size:13px;
    color:#336699;text-decoration:none;
}
.card-footer a:hover{color:#29537c;text-decoration:underline}

/* Invoice row */
.inv-row{
    display:flex;justify-content:space-between;align-items:center;
    padding:.6rem .85rem;
    background:rgba(0,0,0,.03);
    border-bottom:1px solid rgba(0,0,0,.125);
    font-size:13px;color:#6c757d;
}
.inv-row strong{color:#212529}

/* QR */
.qr{text-align:center;margin-bottom:1rem}
.qr img{
    width:170px;height:170px;padding:4px;
    border:1px solid rgba(0,0,0,.125);border-radius:.25rem;
    background:#fff;
}

/* Field */
.field{margin-bottom:1rem}
.field-label{font-size:12px;font-weight:600;color:#6c757d;margin-bottom:.3rem}
.input-group{display:flex}
.input-group input{
    flex:1;min-width:0;
    font-family:SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace;
    font-size:13px;
    padding:.375rem .75rem;
    border:1px solid #ced4da;border-radius:.25rem 0 0 .25rem;
    background:#f8f9fa;color:#495057;outline:none;
}
.input-group input:focus{border-color:#79a6d2;box-shadow:0 0 0 .2rem rgba(51,102,153,.25)}
.input-group .btn{
    border-radius:0 .25rem .25rem 0;
    border:1px solid #336699;border-left:none;
    background:#336699;color:#fff;
    padding:.375rem .75rem;font-size:13px;
    cursor:pointer;white-space:nowrap;
    transition:background .15s;
}
.input-group .btn:hover{background:#29537c}
.input-group .btn.copied{background:#28a745;border-color:#28a745}

/* Amount */
.amount-box{
    border:2px solid #336699;border-radius:.25rem;
    padding:1rem;text-align:center;margin-bottom:1rem;
    background:#f0f5fa;
}
.amount-box .val{
    font-family:SFMono-Regular,Menlo,Monaco,Consolas,monospace;
    font-size:24px;font-weight:700;color:#212529;letter-spacing:.5px;
}
.amount-box .unit{font-size:13px;color:#6c757d;margin-left:4px;font-weight:600}
.amount-box .btn-sm{
    display:inline-block;margin-top:.5rem;
    font-size:12px;padding:.25rem .75rem;
    background:#336699;color:#fff;border:none;border-radius:.2rem;
    cursor:pointer;transition:background .15s;
}
.amount-box .btn-sm:hover{background:#29537c}
.amount-box .btn-sm.copied{background:#28a745}

/* Alert */
.alert{
    font-size:12px;padding:.6rem .85rem;
    border-radius:.25rem;margin-bottom:1rem;
    border:1px solid transparent;text-align:center;
}
.alert-warning{background:#fff3cd;border-color:#ffc107;color:#856404}
.alert-success{background:#d4edda;border-color:#c3e6cb;color:#155724}
.alert-danger{background:#f8d7da;border-color:#f5c6cb;color:#721c24}
.alert-info{background:#e8f4f8;border-color:#bee5eb;color:#0c5460}

/* Timer */
.timer-row{
    display:flex;justify-content:space-between;align-items:center;
    font-size:13px;color:#6c757d;margin-bottom:.4rem;
}
.timer-row .time{
    font-family:SFMono-Regular,Menlo,Monaco,Consolas,monospace;
    font-size:14px;font-weight:500;color:#212529;
}
.progress{
    height:4px;background:#e9ecef;border-radius:.25rem;
    overflow:hidden;margin-bottom:1rem;
}
.progress-bar{
    height:100%;background:#336699;
    border-radius:.25rem;transition:width 1s linear;
}

/* Status */
.status{
    text-align:center;font-size:13px;
    padding:.5rem;border-radius:.25rem;
}
.status-pending{background:#e8f4f8;color:#0c5460}
.status-pending .dot{
    display:inline-block;width:6px;height:6px;
    background:#17a2b8;border-radius:50%;
    margin-right:6px;animation:blink 1.4s infinite;
}
.status-paid{background:#d4edda;color:#155724}
.status-expired{background:#f8d7da;color:#721c24}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.15}}

/* Result */
.result{text-align:center;padding:2rem 1rem}
.result-icon{
    width:50px;height:50px;border-radius:50%;
    display:inline-flex;align-items:center;justify-content:center;
    margin-bottom:.75rem;
}
.result-icon.ok{background:#d4edda}
.result-icon.ok svg{color:#28a745}
.result-icon.fail{background:#f8d7da}
.result-icon.fail svg{color:#dc3545}
.result h3{font-size:16px;font-weight:600;margin-bottom:.25rem}
.result p{font-size:13px;color:#6c757d}

@media(max-width:480px){
    body{padding:20px 10px}
    .card-body{padding:1rem}
    .amount-box .val{font-size:20px}
    .qr img{width:150px;height:150px}
}
</style>
</head>
<body>

<div class="wrap">
<div class="card">
    <div class="card-header">
        <h1>USDT-TRC20 支付</h1>
        <span class="badge">TRC20</span>
    </div>
    <div class="inv-row">
        <span>账单 <strong>#<?php echo (int)$payment->invoice_id; ?></strong></span>
        <span><strong><?php echo htmlspecialchars(number_format($payment->amount_cny, 2)); ?> USD</strong></span>
    </div>

    <div class="card-body" id="payBody">

    <?php if ($isPaid): ?>
        <div class="result">
            <div class="result-icon ok">
                <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"></polyline></svg>
            </div>
            <h3>支付成功</h3>
            <p>交易已确认，正在跳转...</p>
        </div>
        <script>setTimeout(function(){ window.location.href = '<?php echo htmlspecialchars($invoiceUrl); ?>&paymentsuccess=true'; }, 2000);</script>

    <?php elseif ($isExpired): ?>
        <div class="result">
            <div class="result-icon fail">
                <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
            </div>
            <h3>支付已超时</h3>
            <p>请返回账单页面重新发起支付</p>
        </div>

    <?php else: ?>
        <div class="qr">
            <img src="<?php echo htmlspecialchars($qrcodeUrl); ?>" alt="QR">
        </div>

        <div class="field">
            <div class="field-label">收款地址</div>
            <div class="input-group">
                <input type="text" id="walletAddr" value="<?php echo htmlspecialchars($payment->wallet_address); ?>" readonly>
                <button class="btn" onclick="copyText('walletAddr',this)">复制</button>
            </div>
        </div>

        <div class="amount-box">
            <div>
                <span class="val" id="amountValue"><?php echo htmlspecialchars($payment->amount_usdt); ?></span>
                <span class="unit">USDT</span>
            </div>
            <button class="btn-sm" onclick="copyAmount(this)">复制金额</button>
        </div>

        <div class="alert alert-warning">
            请通过 TRC20 网络转入精确金额，否则无法自动到账
        </div>

        <div class="timer-row">
            <span>剩余时间</span>
            <span class="time" id="countdown">--:--</span>
        </div>
        <div class="progress">
            <div class="progress-bar" id="progressBar" style="width:100%"></div>
        </div>

        <div class="status status-pending" id="statusSection">
            <span class="dot"></span>等待付款中
        </div>
    <?php endif; ?>

    </div>

    <div class="card-footer">
        <a href="<?php echo htmlspecialchars($invoiceUrl); ?>">&larr; 返回账单</a>
    </div>
</div>
</div>

<?php if (!$isPaid && !$isExpired): ?>
<script>
(function(){
    var remaining=<?php echo (int)$remainingSeconds; ?>;
    var total=<?php echo intval($payment->expires_at?(strtotime($payment->expires_at)-strtotime($payment->created_at)):1800); ?>;
    var checkUrl='<?php echo $checkUrl; ?>';
    var invoiceUrl='<?php echo htmlspecialchars($invoiceUrl); ?>';
    var polling=null;

    function pad(n){return n<10?'0'+n:''+n}

    function updateTimer(){
        if(remaining<=0){
            document.getElementById('countdown').textContent='00:00';
            document.getElementById('progressBar').style.width='0%';
            var s=document.getElementById('statusSection');
            s.className='status status-expired';
            s.innerHTML='支付已超时，请返回重新发起';
            if(polling){clearInterval(polling);polling=null}
            return;
        }
        var m=Math.floor(remaining/60),sec=remaining%60;
        document.getElementById('countdown').textContent=pad(m)+':'+pad(sec);
        document.getElementById('progressBar').style.width=Math.max(0,(remaining/total)*100)+'%';
        remaining--;
    }

    function checkStatus(){
        var xhr=new XMLHttpRequest();
        xhr.open('GET',checkUrl,true);
        xhr.timeout=8000;
        xhr.onreadystatechange=function(){
            if(xhr.readyState!==4||xhr.status!==200)return;
            try{
                var res=JSON.parse(xhr.responseText);
                if(res.status==='paid'){
                    if(polling){clearInterval(polling);polling=null}
                    var s=document.getElementById('statusSection');
                    s.className='status status-paid';
                    s.innerHTML='支付成功，3 秒后跳转...';
                    setTimeout(function(){window.location.href=invoiceUrl+'&paymentsuccess=true'},3000);
                }else if(res.status==='expired'){
                    if(polling){clearInterval(polling);polling=null}
                    remaining=0;updateTimer();
                }
            }catch(e){}
        };
        xhr.send();
    }

    updateTimer();
    setInterval(updateTimer,1000);
    polling=setInterval(checkStatus,5000);
    checkStatus();
})();

function copyText(id,btn){
    var el=document.getElementById(id);
    if(navigator.clipboard&&navigator.clipboard.writeText){
        navigator.clipboard.writeText(el.value).then(function(){showCopied(btn)});
    }else{el.select();document.execCommand('copy');showCopied(btn)}
}
function copyAmount(btn){
    var t=document.getElementById('amountValue').textContent;
    if(navigator.clipboard&&navigator.clipboard.writeText){
        navigator.clipboard.writeText(t).then(function(){showCopied(btn)});
    }else{
        var tmp=document.createElement('input');tmp.value=t;
        document.body.appendChild(tmp);tmp.select();
        document.execCommand('copy');document.body.removeChild(tmp);
        showCopied(btn);
    }
}
function showCopied(btn){
    var o=btn.textContent;btn.textContent='已复制';btn.classList.add('copied');
    setTimeout(function(){btn.textContent=o;btn.classList.remove('copied')},1200);
}
</script>
<?php endif; ?>
</body>
</html>

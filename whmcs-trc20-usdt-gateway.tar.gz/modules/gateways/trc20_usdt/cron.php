<?php
// USDT-TRC20 自托管网关 - 区块链监控 Cron
// 建议每 2 分钟运行一次

define("WHMCS", true);

require_once __DIR__ . '/../../../init.php';
require_once __DIR__ . '/../../../includes/gatewayfunctions.php';
require_once __DIR__ . '/../../../includes/invoicefunctions.php';

use WHMCS\Database\Capsule;

// USDT TRC20 contract address
const USDT_CONTRACT = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';
const USDT_DECIMALS = 6;

$gatewayParams = getGatewayVariables('trc20_usdt');

if (!$gatewayParams['type']) {
    logAndExit('Gateway module not activated');
}

// Authentication
$isCli = php_sapi_name() === 'cli';
if (!$isCli) {
    $secret = isset($_GET['secret']) ? $_GET['secret'] : '';
    $cronSecret = $gatewayParams['cron_secret'];
    if (empty($cronSecret) || $secret !== $cronSecret) {
        http_response_code(403);
        logAndExit('Unauthorized cron access');
    }
}

$walletAddress = trim($gatewayParams['wallet_address']);
$apiKey = $gatewayParams['trongrid_api_key'];
$gatewayName = $gatewayParams['name'];

if (empty($walletAddress)) {
    logAndExit('Wallet address not configured');
}

// Grace period: keep matching expired payments for 24 hours
$gracePeriodHours = 24;
$graceDeadline = date('Y-m-d H:i:s', time() - $gracePeriodHours * 3600);

// Step 1: Only mark as truly expired after grace period
$expired = Capsule::table('mod_trc20_usdt_payments')
    ->where('status', 0)
    ->where('expires_at', '<', $graceDeadline)
    ->update([
        'status' => 2,
        'updated_at' => date('Y-m-d H:i:s'),
    ]);

if ($expired > 0) {
    logModuleCall('trc20_usdt', 'cron_expire', "Expired {$expired} payments (past {$gracePeriodHours}h grace period)", '');
}

// Step 2: Get all pending payments (including those within grace period)
$pendingPayments = Capsule::table('mod_trc20_usdt_payments')
    ->where('status', 0)
    ->get();

if ($pendingPayments->isEmpty()) {
    logAndExit('No pending payments, skipping API call', false);
}

// Build lookup map: amount_usdt string => payment record
$amountMap = [];
foreach ($pendingPayments as $p) {
    $key = number_format((float)$p->amount_usdt, USDT_DECIMALS, '.', '');
    $amountMap[$key] = $p;
}

// Step 3: Query TronGrid API for recent TRC20 transfers
$oldestCreated = $pendingPayments->min('created_at');
$minTimestamp = (strtotime($oldestCreated) - 300) * 1000; // 5 minutes before oldest pending

$apiUrl = 'https://api.trongrid.io/v1/accounts/' . $walletAddress . '/transactions/trc20'
    . '?only_confirmed=true'
    . '&contract_address=' . USDT_CONTRACT
    . '&limit=200'
    . '&min_timestamp=' . $minTimestamp
    . '&order_by=block_timestamp,desc';

$headers = ['Content-Type: application/json'];
if (!empty($apiKey)) {
    $headers[] = 'TRON-PRO-API-KEY: ' . $apiKey;
}

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

logModuleCall('trc20_usdt', 'cron_trongrid_request', $apiUrl, "HTTP {$httpCode}, Error: {$curlError}");

if ($response === false || $httpCode !== 200) {
    logModuleCall('trc20_usdt', 'cron_trongrid_error', "HTTP {$httpCode}", $response ?: $curlError);
    logAndExit('TronGrid API request failed');
}

$result = json_decode($response, true);
if (!$result || !isset($result['data'])) {
    logModuleCall('trc20_usdt', 'cron_trongrid_parse_error', $response, '');
    logAndExit('Failed to parse TronGrid response');
}

$matched = 0;
$tolerance = 0.0001;

foreach ($result['data'] as $tx) {
    // Only process incoming transfers to our wallet
    if (!isset($tx['to']) || strtolower($tx['to']) !== strtolower($walletAddress)) {
        continue;
    }

    $txid = $tx['transaction_id'];
    $rawValue = $tx['value'];
    $receivedAmount = bcdiv($rawValue, bcpow('10', (string)USDT_DECIMALS), USDT_DECIMALS);
    $receivedStr = number_format((float)$receivedAmount, USDT_DECIMALS, '.', '');

    // Check if this txid is already processed
    $existingTx = Capsule::table('mod_trc20_usdt_payments')
        ->where('txid', $txid)
        ->exists();

    if ($existingTx) {
        continue;
    }

    // Try exact match first
    $matchedPayment = null;
    if (isset($amountMap[$receivedStr])) {
        $matchedPayment = $amountMap[$receivedStr];
    } else {
        // Try tolerance match
        foreach ($amountMap as $expectedStr => $p) {
            $diff = abs((float)$receivedAmount - (float)$expectedStr);
            if ($diff <= $tolerance) {
                $matchedPayment = $p;
                break;
            }
        }
    }

    if (!$matchedPayment) {
        logModuleCall('trc20_usdt', 'cron_unmatched_tx', [
            'txid' => $txid,
            'amount' => $receivedStr,
            'from' => $tx['from'] ?? 'unknown',
        ], 'No matching pending payment found');
        continue;
    }

    // Match found - process payment
    try {
        $invoiceId = $matchedPayment->invoice_id;

        // Update payment record
        Capsule::table('mod_trc20_usdt_payments')
            ->where('id', $matchedPayment->id)
            ->update([
                'status' => 1,
                'txid' => $txid,
                'actual_amount' => $receivedAmount,
                'paid_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

        // Remove from lookup map to prevent double matching
        $key = number_format((float)$matchedPayment->amount_usdt, USDT_DECIMALS, '.', '');
        unset($amountMap[$key]);

        // WHMCS payment processing
        $invoiceId = checkCbInvoiceID($invoiceId, $gatewayName);
        checkCbTransID($txid);
        logTransaction($gatewayName, [
            'txid' => $txid,
            'amount_usdt' => $receivedStr,
            'invoice_id' => $invoiceId,
            'from' => $tx['from'] ?? '',
            'block_timestamp' => $tx['block_timestamp'] ?? '',
        ], 'Successful');

        addInvoicePayment(
            $invoiceId,
            $txid,
            $matchedPayment->amount_cny, // Original invoice amount
            0,
            $gatewayName
        );

        $matched++;

        logModuleCall('trc20_usdt', 'cron_payment_matched', [
            'invoice_id' => $invoiceId,
            'txid' => $txid,
            'expected' => number_format((float)$matchedPayment->amount_usdt, USDT_DECIMALS, '.', ''),
            'received' => $receivedStr,
        ], 'Payment applied successfully');

    } catch (\Exception $e) {
        logModuleCall('trc20_usdt', 'cron_payment_error', [
            'invoice_id' => $matchedPayment->invoice_id,
            'txid' => $txid,
        ], $e->getMessage());
    }
}

logModuleCall('trc20_usdt', 'cron_complete', [
    'pending_count' => $pendingPayments->count(),
    'transactions_checked' => count($result['data']),
    'matched' => $matched,
    'expired' => $expired,
], 'Cron run completed');

if (!$isCli) {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'ok',
        'matched' => $matched,
        'expired' => $expired,
    ]);
}

function logAndExit($message, $isError = true)
{
    if ($isError) {
        logModuleCall('trc20_usdt', 'cron_exit', $message, '');
    }

    if (php_sapi_name() !== 'cli') {
        header('Content-Type: application/json');
        echo json_encode(['status' => $isError ? 'error' : 'ok', 'message' => $message]);
    }
    exit();
}

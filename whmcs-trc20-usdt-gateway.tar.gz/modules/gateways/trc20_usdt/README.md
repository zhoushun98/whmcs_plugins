# WHMCS USDT-TRC20 自托管收款网关

无需第三方支付平台，直接监控 TRON 区块链，收款到你自己的钱包地址。

## 功能特点

- 自托管，不依赖任何第三方支付平台
- 通过 TronGrid API 自动监控链上转账
- 唯一金额后缀机制，自动匹配交易与账单
- 支付页面带 QR 码、一键复制、倒计时、自动检测到账
- 支持自定义汇率和超时时间
- 数据库表自动创建，无需手动操作

## 文件结构

```
modules/
├── gateways/
│   ├── trc20_usdt.php                 # 主网关模块
│   ├── trc20_usdt/
│   │   ├── pay.php                    # 支付页面
│   │   ├── qrcode.php                 # QR 码生成
│   │   ├── cron.php                   # 区块链监控 Cron
│   │   └── README.md                  # 本文件
│   └── callback/
│       └── trc20_usdt.php             # AJAX 状态检查端点
```

## 安装

1. 将 `modules/` 目录下的所有文件上传到 WHMCS 根目录，保持目录结构
2. 登录 WHMCS 后台 → System Settings → Payment Gateways
3. 找到 **USDT-TRC20 (自托管)** 并点击激活
4. 填写配置参数（见下方）
5. 添加 Crontab（见下方）

数据库表 `mod_trc20_usdt_payments` 会在首次进入网关配置页面时自动创建。

## 配置参数

| 参数 | 说明 |
|------|------|
| TRC20 收款地址 | 你的 TRON 钱包地址，以 T 开头（34 位） |
| TronGrid API Key | 可选，在 [trongrid.io](https://www.trongrid.io/) 免费申请，防止 API 限流 |
| USD/USDT 汇率 | 默认 `1.00`，可根据需要调整 |
| 支付超时（分钟） | 支付页面倒计时，默认 `30` 分钟 |
| Cron 密钥 | 仅 HTTP 方式调用 Cron 时需要，CLI 方式留空即可 |

## Cron 设置

**方式一：CLI（推荐）**

```bash
*/2 * * * * /usr/bin/php /你的WHMCS路径/modules/gateways/trc20_usdt/cron.php >> /dev/null 2>&1
```

**方式二：HTTP**

先在后台填写 Cron 密钥，然后：

```bash
*/2 * * * * curl -s "https://你的域名/modules/gateways/trc20_usdt/cron.php?secret=你的密钥" >> /dev/null 2>&1
```

## 工作原理

1. 用户在 WHMCS 账单页点击付款，系统生成一个带唯一小数后缀的 USDT 金额（如 `180.0013`）
2. 支付页面展示钱包地址二维码和精确金额，用户用钱包 App 转账
3. Cron 每 2 分钟查询 TronGrid API，获取钱包的 TRC20 转入记录
4. 通过精确金额匹配，自动关联交易与账单，标记为已支付
5. 支付页面每 5 秒 AJAX 轮询状态，检测到付款成功后自动跳转

## 环境要求

- WHMCS 8.x / 9.x
- PHP 7.4+（需要 `curl`、`json`、`bcmath` 扩展）
- 服务器可访问 `api.trongrid.io`

## 注意事项

- 用户必须通过 **TRC20 网络** 转入精确金额，否则无法自动匹配
- 超时未付的订单会自动标记为过期，用户可返回账单重新发起
- 如果用户转错金额或超时后转账，交易会记录在网关日志中，需管理员手动处理
- 网关日志查看路径：WHMCS 后台 → Utilities → Logs → Gateway Log

## 许可

MIT License

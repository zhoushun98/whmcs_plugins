<?php
require_once __DIR__ . '/../../../vendor/autoload.php';

use BaconQrCode\Renderer\ImageRenderer;
use BaconQrCode\Renderer\Image\SvgImageBackEnd;
use BaconQrCode\Renderer\RendererStyle\RendererStyle;
use BaconQrCode\Writer;

$data = isset($_GET['data']) ? $_GET['data'] : '';

// Only allow TRC20 address format
if (!preg_match('/^T[A-Za-z0-9]{33}$/', $data)) {
    http_response_code(400);
    die('Invalid address');
}

$renderer = new ImageRenderer(
    new RendererStyle(300, 2),
    new SvgImageBackEnd()
);

$writer = new Writer($renderer);

header('Content-Type: image/svg+xml');
header('Cache-Control: public, max-age=86400');
echo $writer->writeString($data);

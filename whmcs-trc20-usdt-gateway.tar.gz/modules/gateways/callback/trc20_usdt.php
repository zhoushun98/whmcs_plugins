<?php
require_once __DIR__ . '/../../../init.php';
require_once __DIR__ . '/../../../includes/gatewayfunctions.php';
require_once __DIR__ . '/../../../includes/invoicefunctions.php';

use WHMCS\Database\Capsule;

$gatewayParams = getGatewayVariables('trc20_usdt');

if (!$gatewayParams['type']) {
    http_response_code(400);
    die('Module not active');
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($action === 'check_status') {
    header('Content-Type: application/json');

    $token = isset($_GET['token']) ? preg_replace('/[^a-f0-9]/', '', $_GET['token']) : '';

    if (empty($token) || strlen($token) !== 64) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid token']);
        exit();
    }

    $payment = Capsule::table('mod_trc20_usdt_payments')
        ->where('token', $token)
        ->first();

    if (!$payment) {
        echo json_encode(['status' => 'error', 'message' => 'Payment not found']);
        exit();
    }

    if ($payment->status == 1) {
        echo json_encode([
            'status' => 'paid',
            'txid' => $payment->txid,
        ]);
    } elseif ($payment->status == 2 || (strtotime($payment->expires_at) < time() && $payment->status == 0)) {
        echo json_encode(['status' => 'expired']);
    } else {
        $remaining = max(0, strtotime($payment->expires_at) - time());
        echo json_encode([
            'status' => 'pending',
            'expires_in' => $remaining,
        ]);
    }
    exit();
}

// Default: return 404 for unknown actions
http_response_code(404);
echo 'Not found';

<?php

/**
 * Inject "批量修改注册日期" field into admin client summary page,
 * and handle the AJAX update request independently (no dependency on other addons).
 */

use WHMCS\Database\Capsule;

// Handle AJAX request for bulk regdate update
add_hook('AdminAreaHeaderOutput', 1, function ($vars) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST'
        || !isset($_REQUEST['bulk_regdate_action'])
        || $_REQUEST['bulk_regdate_action'] !== 'update'
    ) {
        return '';
    }

    header('Content-Type: application/json');

    $regdate = isset($_POST['regdate']) ? trim($_POST['regdate']) : '';
    $hostingIds = isset($_POST['hosting_ids']) ? trim($_POST['hosting_ids']) : '';

    if (empty($regdate)) {
        echo json_encode(['success' => false, 'message' => '请输入日期']);
        exit;
    }

    $ts = strtotime($regdate);
    if (!$ts) {
        echo json_encode(['success' => false, 'message' => '日期格式无法识别']);
        exit;
    }
    $regdate = date('Y-m-d', $ts);

    if (empty($hostingIds)) {
        echo json_encode(['success' => false, 'message' => '未选择产品']);
        exit;
    }

    $ids = array_map('intval', explode(',', $hostingIds));
    $ids = array_filter($ids, function ($id) { return $id > 0; });

    if (empty($ids)) {
        echo json_encode(['success' => false, 'message' => '无有效的产品ID']);
        exit;
    }

    $count = Capsule::table('tblhosting')
        ->whereIn('id', $ids)
        ->update(['regdate' => $regdate]);

    echo json_encode(['success' => true, 'count' => $count]);
    exit;
});

// Inject UI into admin client summary page
add_hook('AdminAreaFooterOutput', 1, function ($vars) {
    if (!isset($vars['filename']) || $vars['filename'] !== 'clientssummary') {
        return '';
    }

    return <<<'HTML'
<script>
(function() {
    function init() {
        var allLabels = document.querySelectorAll('td');
        var targetRow = null;

        for (var i = 0; i < allLabels.length; i++) {
            var text = allLabels[i].textContent.trim();
            if (text === '下一个到期日期' || text === 'Next Due Date' || text === '下一個到期日期') {
                targetRow = allLabels[i].closest('tr');
                break;
            }
        }

        if (!targetRow || !targetRow.parentNode) return;

        var newRow = document.createElement('tr');
        newRow.innerHTML = '<td class="fieldlabel">注册日期</td>' +
            '<td class="fieldarea">' +
                '<div class="form-group date-picker-prepend-icon">' +
                    '<label for="bulk_regdate" class="field-icon"><i class="fal fa-calendar-alt"></i></label>' +
                    '<input type="text" id="bulk_regdate" class="input-inline form-control date-picker-single" data-drops="up" value="" />' +
                    '&nbsp;&nbsp; <button type="button" id="bulk_regdate_btn" class="btn btn-default" style="vertical-align:top;">确认修改</button>' +
                '</div>' +
            '</td>';
        targetRow.parentNode.insertBefore(newRow, targetRow.nextSibling);

        if (window.jQuery && jQuery.fn.daterangepicker && typeof adminJsVars !== 'undefined') {
            var fmt = adminJsVars.dateRangeFormat;
            jQuery('#bulk_regdate').daterangepicker({
                singleDatePicker: true,
                autoUpdateInput: false,
                ranges: adminJsVars.dateRangePicker.defaultSingleRanges,
                alwaysShowCalendars: true,
                opens: 'center',
                drops: 'up',
                showDropdowns: true,
                minYear: adminJsVars.minYear,
                maxYear: adminJsVars.maxYear,
                locale: {
                    format: fmt,
                    customRangeLabel: adminJsVars.dateRangePicker.customRangeLabel,
                    monthNames: adminJsVars.dateRangePicker.months,
                    daysOfWeek: adminJsVars.dateRangePicker.daysOfWeek
                }
            }).on('apply.daterangepicker', function(ev, picker) {
                jQuery(this).data('original-value', picker.startDate.format(fmt)).val(picker.startDate.format(fmt));
            }).on('cancel.daterangepicker', function(ev, picker) {
                jQuery(this).val(jQuery(this).data('original-value'));
            });
        }

        document.getElementById('bulk_regdate_btn').addEventListener('click', function() {
            var dateVal = document.getElementById('bulk_regdate').value.trim();
            if (!dateVal) {
                alert('请选择注册日期');
                return;
            }

            var checks = document.querySelectorAll('input[name="selectedproducts[]"]:checked');
            if (!checks || checks.length === 0) {
                checks = document.querySelectorAll('input[name="selproducts[]"]:checked');
            }
            if (!checks || checks.length === 0) {
                checks = document.querySelectorAll('#sortabletbl0 input[type="checkbox"]:checked');
            }

            var ids = [];
            checks.forEach(function(cb) {
                var val = cb.value;
                if (val && val !== 'on' && val !== '') {
                    ids.push(val);
                }
            });

            if (ids.length === 0) {
                alert('请先在产品/服务列表中勾选要修改的产品');
                return;
            }

            if (!confirm('确认将选中的 ' + ids.length + ' 个产品的注册日期修改为 ' + dateVal + ' ？')) {
                return;
            }

            var btn = document.getElementById('bulk_regdate_btn');
            btn.disabled = true;
            btn.textContent = '处理中...';

            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'clientssummary.php?userid=' + jQuery('input[name="userid"]').val() + '&bulk_regdate_action=update');
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function() {
                btn.disabled = false;
                btn.textContent = '确认修改';
                if (xhr.status === 200) {
                    try {
                        var resp = JSON.parse(xhr.responseText);
                        if (resp.success) {
                            alert('成功修改 ' + resp.count + ' 个产品的注册日期');
                            location.reload();
                        } else {
                            alert('修改失败: ' + (resp.message || '未知错误'));
                        }
                    } catch(e) {
                        alert('修改失败: 响应解析错误');
                    }
                } else {
                    alert('请求失败');
                }
            };
            xhr.onerror = function() {
                btn.disabled = false;
                btn.textContent = '确认修改';
                alert('网络错误');
            };
            xhr.send('regdate=' + encodeURIComponent(dateVal) + '&hosting_ids=' + encodeURIComponent(ids.join(',')));
        });
    }

    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        setTimeout(init, 500);
    } else {
        document.addEventListener('DOMContentLoaded', function() { setTimeout(init, 500); });
    }
})();
</script>
HTML;
});

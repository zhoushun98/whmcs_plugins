<?php

add_hook('ClientAreaHomepagePanels', 1, function ($homePagePanels) {
    if (empty($_SESSION['uid']) || !is_object($homePagePanels) || !method_exists($homePagePanels, 'addChild')) {
        return;
    }

    $credit = 0.00;
    try {
        if (class_exists('\\WHMCS\\Database\\Capsule')) {
            $credit = (float) \WHMCS\Database\Capsule::table('tblclients')
                ->where('id', (int) $_SESSION['uid'])
                ->value('credit');
        }
    } catch (\Exception $e) {
        $credit = 0.00;
    }

    $formattedCredit = function_exists('formatCurrency') ? formatCurrency($credit) : $credit;

    $balancePanel = $homePagePanels->addChild('Account Balance', [
        'label' => '可用帐上余额',
        'order' => 28,
        'extras' => [
            'color' => 'red',
            'btn-link' => 'clientarea.php?action=addfunds',
            'btn-text' => '加值',
            'btn-icon' => 'fas fa-plus',
        ],
    ]);

    if (!is_object($balancePanel)) {
        return;
    }

    if (method_exists($balancePanel, 'setBodyHtml')) {
        $balancePanel->setBodyHtml(
            '<div style="font-size:13px;line-height:1.8;padding:8px 10px;color:#4b5563;">您目前帐上余额有 <strong>' . $formattedCredit . '</strong>，我们将在您有新帐单时自动以帐上余额扣抵。</div>'
        );
    }

});

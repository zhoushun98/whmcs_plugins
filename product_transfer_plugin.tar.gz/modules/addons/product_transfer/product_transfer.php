<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use WHMCS\Database\Capsule;

function product_transfer_config()
{
    return [
        'name' => '产品批量转移',
        'description' => '管理员可批量将产品/服务的所有权从一个客户转移到另一个客户',
        'version' => '1.0.0',
        'author' => 'ProductTransfer',
        'language' => 'chinese',
        'fields' => [],
    ];
}

function product_transfer_activate()
{
    try {
        if (!Capsule::schema()->hasTable('mod_product_transfer_logs')) {
            Capsule::schema()->create('mod_product_transfer_logs', function ($table) {
                $table->increments('id');
                $table->integer('hosting_id');
                $table->string('product_name', 255)->default('');
                $table->integer('from_user_id');
                $table->integer('to_user_id');
                $table->string('admin_user', 100)->default('');
                $table->timestamp('created_at')->useCurrent();
            });
        }
        return ['status' => 'success', 'description' => '产品批量转移模块激活成功'];
    } catch (\Exception $e) {
        return ['status' => 'error', 'description' => '激活失败: ' . $e->getMessage()];
    }
}

function product_transfer_deactivate()
{
    try {
        Capsule::schema()->dropIfExists('mod_product_transfer_logs');
        return ['status' => 'success', 'description' => '产品批量转移模块已停用'];
    } catch (\Exception $e) {
        return ['status' => 'error', 'description' => '停用失败: ' . $e->getMessage()];
    }
}

function product_transfer_output($vars)
{
    $modulelink = $vars['modulelink'];
    $action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';



    if ($action === 'search_clients') {
        product_transfer_ajaxSearchClients();
        return;
    }

    if ($action === 'load_products') {
        product_transfer_ajaxLoadProducts();
        return;
    }

    if ($action === 'clear_logs' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        Capsule::table('mod_product_transfer_logs')->truncate();
        $_SESSION['transfer_clear'] = true;
    }

    if ($action === 'do_transfer' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        product_transfer_doTransfer($vars);
    }

    product_transfer_renderPage($vars);
}

function product_transfer_ajaxSearchClients()
{
    $keyword = isset($_REQUEST['keyword']) ? trim($_REQUEST['keyword']) : '';
    if (strlen($keyword) < 1) {
        header('Content-Type: application/json');
        echo json_encode([]);
        exit;
    }

    $clients = Capsule::table('tblclients')
        ->where(function ($q) use ($keyword) {
            $q->where('firstname', 'like', "%{$keyword}%")
              ->orWhere('lastname', 'like', "%{$keyword}%")
              ->orWhere('email', 'like', "%{$keyword}%")
              ->orWhere('companyname', 'like', "%{$keyword}%")
              ->orWhere('id', $keyword);
        })
        ->select('id', 'firstname', 'lastname', 'email', 'companyname')
        ->limit(20)
        ->get();

    $results = [];
    foreach ($clients as $c) {
        $name = trim($c->firstname . ' ' . $c->lastname);
        if ($c->companyname) {
            $name .= ' (' . $c->companyname . ')';
        }
        $results[] = [
            'id' => $c->id,
            'name' => $name,
            'email' => $c->email,
            'label' => "#{$c->id} - {$name} - {$c->email}",
        ];
    }

    header('Content-Type: application/json');
    echo json_encode($results);
    exit;
}

function product_transfer_ajaxLoadProducts()
{
    $userId = isset($_REQUEST['user_id']) ? (int)$_REQUEST['user_id'] : 0;
    if (!$userId) {
        header('Content-Type: application/json');
        echo json_encode([]);
        exit;
    }

    $products = Capsule::table('tblhosting as h')
        ->join('tblproducts as p', 'h.packageid', '=', 'p.id')
        ->where('h.userid', $userId)
        ->select(
            'h.id', 'h.domain', 'h.domainstatus', 'h.billingcycle',
            'h.amount', 'h.nextduedate', 'h.regdate',
            'p.name as product_name'
        )
        ->orderBy('h.id', 'asc')
        ->get();

    $results = [];
    foreach ($products as $p) {
        $results[] = [
            'id' => $p->id,
            'product_name' => $p->product_name,
            'domain' => $p->domain ?: '-',
            'status' => $p->domainstatus,
            'billingcycle' => $p->billingcycle,
            'amount' => number_format((float)$p->amount, 2),
            'nextduedate' => $p->nextduedate,
            'regdate' => $p->regdate,
        ];
    }

    header('Content-Type: application/json');
    echo json_encode($results);
    exit;
}

function product_transfer_doTransfer($vars)
{
    $fromUserId = isset($_POST['from_user_id']) ? (int)$_POST['from_user_id'] : 0;
    $toUserId = isset($_POST['to_user_id']) ? (int)$_POST['to_user_id'] : 0;
    $selectedIds = isset($_POST['hosting_ids']) ? (array)$_POST['hosting_ids'] : [];

    if (!$fromUserId || !$toUserId || empty($selectedIds)) {
        return;
    }

    if ($fromUserId === $toUserId) {
        return;
    }

    $toClient = Capsule::table('tblclients')->where('id', $toUserId)->first();
    if (!$toClient) {
        return;
    }

    $adminUser = isset($_SESSION['adminid']) ? $_SESSION['adminid'] : 0;
    $adminName = '';
    if ($adminUser) {
        $admin = Capsule::table('tbladmins')->where('id', $adminUser)->first();
        if ($admin) {
            $adminName = trim($admin->firstname . ' ' . $admin->lastname);
        }
    }

    $transferred = 0;
    foreach ($selectedIds as $hostingId) {
        $hostingId = (int)$hostingId;
        $hosting = Capsule::table('tblhosting as h')
            ->join('tblproducts as p', 'h.packageid', '=', 'p.id')
            ->where('h.id', $hostingId)
            ->where('h.userid', $fromUserId)
            ->select('h.id', 'p.name as product_name', 'h.domain')
            ->first();

        if (!$hosting) {
            continue;
        }

        Capsule::table('tblhosting')
            ->where('id', $hostingId)
            ->update(['userid' => $toUserId]);

        $productLabel = $hosting->product_name;
        if ($hosting->domain) {
            $productLabel .= ' - ' . $hosting->domain;
        }

        Capsule::table('mod_product_transfer_logs')->insert([
            'hosting_id' => $hostingId,
            'product_name' => $productLabel,
            'from_user_id' => $fromUserId,
            'to_user_id' => $toUserId,
            'admin_user' => $adminName,
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        $transferred++;
    }

    $_SESSION['transfer_success'] = $transferred;
}

function product_transfer_renderPage($vars)
{
    $modulelink = $vars['modulelink'];

    if (isset($_SESSION['transfer_success'])) {
        $count = (int)$_SESSION['transfer_success'];
        unset($_SESSION['transfer_success']);
        echo '<div class="alert alert-success">';
        echo "<strong>转移成功！</strong> 已成功转移 {$count} 个产品/服务。";
        echo '</div>';
    }

    echo <<<HTML
<div class="panel panel-default">
    <div class="panel-heading">
        <h3 class="panel-title"><i class="fas fa-exchange-alt"></i> 产品批量转移</h3>
    </div>
    <div class="panel-body">
        <form method="post" action="{$modulelink}&action=do_transfer" id="transferForm">
            <div class="row">
                <div class="col-md-5">
                    <div class="form-group">
                        <label><strong>源客户（转出方）</strong></label>
                        <input type="text" class="form-control" id="fromClientSearch" placeholder="输入客户ID、姓名或邮箱搜索..." autocomplete="off">
                        <input type="hidden" name="from_user_id" id="fromUserId">
                        <div id="fromClientDropdown" class="dropdown-menu" style="width:100%;max-height:250px;overflow-y:auto;"></div>
                        <div id="fromClientInfo" class="mt-2"></div>
                    </div>
                </div>
                <div class="col-md-2 text-center" style="padding-top:30px;">
                    <i class="fas fa-arrow-right fa-2x text-primary"></i>
                </div>
                <div class="col-md-5">
                    <div class="form-group">
                        <label><strong>目标客户（转入方）</strong></label>
                        <input type="text" class="form-control" id="toClientSearch" placeholder="输入客户ID、姓名或邮箱搜索..." autocomplete="off">
                        <input type="hidden" name="to_user_id" id="toUserId">
                        <div id="toClientDropdown" class="dropdown-menu" style="width:100%;max-height:250px;overflow-y:auto;"></div>
                        <div id="toClientInfo" class="mt-2"></div>
                    </div>
                </div>
            </div>

            <div id="productListSection" style="display:none;">
                <hr>
                <h4><i class="fas fa-server"></i> 源客户产品列表 <span id="productCount" class="badge badge-default"></span></h4>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered" id="productTable">
                        <thead>
                            <tr>
                                <th style="width:40px"><input type="checkbox" id="checkAllProducts"></th>
                                <th>ID</th>
                                <th>产品名称</th>
                                <th>域名</th>
                                <th>状态</th>
                                <th>计费周期</th>
                                <th>金额</th>
                                <th>注册日期</th>
                                <th>到期日期</th>
                            </tr>
                        </thead>
                        <tbody id="productTableBody">
                        </tbody>
                    </table>
                </div>

                <div class="text-center mt-3">
                    <button type="submit" class="btn btn-danger btn-lg" id="transferBtn" disabled>
                        <i class="fas fa-exchange-alt"></i> 确认转移 (<span id="selectedCount">0</span> 项)
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
HTML;

    product_transfer_renderLogs($vars);
    product_transfer_renderScript($vars);
}

function product_transfer_renderLogs($vars)
{
    $modulelink = $vars['modulelink'];
    $page = isset($_GET['logpage']) ? max(1, (int)$_GET['logpage']) : 1;
    $perPage = 20;
    $offset = ($page - 1) * $perPage;

    $totalLogs = Capsule::table('mod_product_transfer_logs')->count();
    $totalPages = max(1, ceil($totalLogs / $perPage));

    $logs = Capsule::table('mod_product_transfer_logs as l')
        ->leftJoin('tblclients as cf', 'l.from_user_id', '=', 'cf.id')
        ->leftJoin('tblclients as ct', 'l.to_user_id', '=', 'ct.id')
        ->select(
            'l.*',
            Capsule::raw("CONCAT(cf.firstname, ' ', cf.lastname, ' (', cf.email, ')') as from_client"),
            Capsule::raw("CONCAT(ct.firstname, ' ', ct.lastname, ' (', ct.email, ')') as to_client")
        )
        ->orderBy('l.created_at', 'desc')
        ->offset($offset)
        ->limit($perPage)
        ->get();

    if (isset($_SESSION['transfer_clear'])) {
        unset($_SESSION['transfer_clear']);
        echo '<div class="alert alert-success">转移记录已清空。</div>';
    }

    echo '<div class="panel panel-default">';
    echo '<div class="panel-heading clearfix"><h3 class="panel-title pull-left"><i class="fas fa-history"></i> 转移记录</h3>';
    echo '<form method="post" action="' . $modulelink . '&action=clear_logs" class="pull-right" style="margin:0;" onsubmit="return confirm(\'确认清空所有转移记录？此操作不可恢复！\');">';
    echo '<button type="submit" class="btn btn-danger btn-xs"><i class="fas fa-trash"></i> 清空记录</button>';
    echo '</form></div>';
    echo '<div class="panel-body table-responsive">';
    echo '<table class="table table-striped table-bordered">';
    echo '<thead><tr>';
    echo '<th>ID</th><th>产品ID</th><th>产品名称</th><th>源客户</th><th>目标客户</th><th>操作管理员</th><th>时间</th>';
    echo '</tr></thead><tbody>';

    foreach ($logs as $log) {
        echo '<tr>';
        echo '<td>' . $log->id . '</td>';
        echo '<td><a href="clientshosting.php?id=' . $log->hosting_id . '">#' . $log->hosting_id . '</a></td>';
        echo '<td>' . htmlspecialchars($log->product_name) . '</td>';
        echo '<td><a href="clientssummary.php?userid=' . $log->from_user_id . '">' . htmlspecialchars($log->from_client) . '</a></td>';
        echo '<td><a href="clientssummary.php?userid=' . $log->to_user_id . '">' . htmlspecialchars($log->to_client) . '</a></td>';
        echo '<td>' . htmlspecialchars($log->admin_user) . '</td>';
        echo '<td>' . $log->created_at . '</td>';
        echo '</tr>';
    }

    if (count($logs) === 0) {
        echo '<tr><td colspan="7" class="text-center">暂无转移记录</td></tr>';
    }

    echo '</tbody></table>';

    if ($totalPages > 1) {
        echo '<nav><ul class="pagination">';
        for ($i = 1; $i <= $totalPages; $i++) {
            $active = $i === $page ? ' class="active"' : '';
            echo '<li' . $active . '><a href="' . $modulelink . '&logpage=' . $i . '">' . $i . '</a></li>';
        }
        echo '</ul></nav>';
    }

    echo '</div></div>';
}

function product_transfer_renderScript($vars)
{
    $modulelink = $vars['modulelink'];

    echo <<<SCRIPT
<script>
(function() {
    var modulelink = '{$modulelink}';
    var searchTimer = null;

    function setupClientSearch(inputId, dropdownId, hiddenId, infoId, onSelect) {
        var input = document.getElementById(inputId);
        var dropdown = document.getElementById(dropdownId);
        var hidden = document.getElementById(hiddenId);
        var info = document.getElementById(infoId);

        input.addEventListener('input', function() {
            var val = this.value.trim();
            hidden.value = '';
            info.innerHTML = '';

            if (searchTimer) clearTimeout(searchTimer);
            if (val.length < 1) {
                dropdown.style.display = 'none';
                dropdown.innerHTML = '';
                return;
            }

            searchTimer = setTimeout(function() {
                var xhr = new XMLHttpRequest();
                xhr.open('GET', modulelink + '&action=search_clients&keyword=' + encodeURIComponent(val));
                xhr.onload = function() {
                    if (xhr.status === 200) {
                        var data = JSON.parse(xhr.responseText);
                        dropdown.innerHTML = '';
                        if (data.length === 0) {
                            dropdown.innerHTML = '<a class="dropdown-item disabled" href="#">未找到匹配客户</a>';
                        } else {
                            data.forEach(function(c) {
                                var a = document.createElement('a');
                                a.className = 'dropdown-item';
                                a.href = '#';
                                a.textContent = c.label;
                                a.setAttribute('data-id', c.id);
                                a.setAttribute('data-name', c.name);
                                a.setAttribute('data-email', c.email);
                                a.addEventListener('click', function(e) {
                                    e.preventDefault();
                                    hidden.value = c.id;
                                    input.value = c.label;
                                    info.innerHTML = '<span class="label label-info">#' + c.id + '</span> <strong>' + c.name + '</strong> &lt;' + c.email + '&gt;';
                                    dropdown.style.display = 'none';
                                    if (onSelect) onSelect(c.id);
                                });
                                dropdown.appendChild(a);
                            });
                        }
                        dropdown.style.display = 'block';
                    }
                };
                xhr.send();
            }, 300);
        });

        document.addEventListener('click', function(e) {
            if (!dropdown.contains(e.target) && e.target !== input) {
                dropdown.style.display = 'none';
            }
        });
    }

    function loadProducts(userId) {
        var section = document.getElementById('productListSection');
        var tbody = document.getElementById('productTableBody');
        var countBadge = document.getElementById('productCount');

        tbody.innerHTML = '<tr><td colspan="9" class="text-center">加载中...</td></tr>';
        section.style.display = 'block';

        var xhr = new XMLHttpRequest();
        xhr.open('GET', modulelink + '&action=load_products&user_id=' + userId);
        xhr.onload = function() {
            if (xhr.status === 200) {
                var data = JSON.parse(xhr.responseText);
                tbody.innerHTML = '';
                countBadge.textContent = data.length + ' 项';

                if (data.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="9" class="text-center">该客户名下没有产品/服务</td></tr>';
                    return;
                }

                var statusMap = {
                    'Active': '<span class="label label-success">Active</span>',
                    'Suspended': '<span class="label label-warning">Suspended</span>',
                    'Terminated': '<span class="label label-danger">Terminated</span>',
                    'Cancelled': '<span class="label label-default">Cancelled</span>',
                    'Pending': '<span class="label label-info">Pending</span>',
                    'Fraud': '<span class="label label-danger">Fraud</span>',
                    'Completed': '<span class="label label-primary">Completed</span>'
                };

                data.forEach(function(p) {
                    var tr = document.createElement('tr');
                    var statusLabel = statusMap[p.status] || p.status;
                    tr.innerHTML = '<td><input type="checkbox" name="hosting_ids[]" value="' + p.id + '" class="product-check"></td>'
                        + '<td>' + p.id + '</td>'
                        + '<td>' + p.product_name + '</td>'
                        + '<td>' + p.domain + '</td>'
                        + '<td>' + statusLabel + '</td>'
                        + '<td>' + p.billingcycle + '</td>'
                        + '<td>$' + p.amount + '</td>'
                        + '<td>' + p.regdate + '</td>'
                        + '<td>' + p.nextduedate + '</td>';
                    tbody.appendChild(tr);
                });

                bindCheckboxes();
            }
        };
        xhr.send();
    }

    function bindCheckboxes() {
        var checks = document.querySelectorAll('.product-check');
        checks.forEach(function(cb) {
            cb.addEventListener('change', updateTransferBtn);
        });
    }

    function updateTransferBtn() {
        var checked = document.querySelectorAll('.product-check:checked').length;
        var toUser = document.getElementById('toUserId').value;
        document.getElementById('selectedCount').textContent = checked;
        document.getElementById('transferBtn').disabled = (checked === 0 || !toUser);
    }

    document.getElementById('checkAllProducts').addEventListener('change', function() {
        var val = this.checked;
        document.querySelectorAll('.product-check').forEach(function(cb) {
            cb.checked = val;
        });
        updateTransferBtn();
    });

    setupClientSearch('fromClientSearch', 'fromClientDropdown', 'fromUserId', 'fromClientInfo', function(userId) {
        loadProducts(userId);
    });

    setupClientSearch('toClientSearch', 'toClientDropdown', 'toUserId', 'toClientInfo', function() {
        updateTransferBtn();
    });

    document.getElementById('transferForm').addEventListener('submit', function(e) {
        var fromId = document.getElementById('fromUserId').value;
        var toId = document.getElementById('toUserId').value;
        var checked = document.querySelectorAll('.product-check:checked').length;

        if (!fromId || !toId || checked === 0) {
            e.preventDefault();
            alert('请选择源客户、目标客户，并勾选要转移的产品');
            return;
        }

        if (fromId === toId) {
            e.preventDefault();
            alert('源客户和目标客户不能相同');
            return;
        }

        if (!confirm('确认将选中的 ' + checked + ' 个产品从源客户转移到目标客户？此操作不可撤销！')) {
            e.preventDefault();
            return;
        }

        document.getElementById('transferBtn').disabled = true;
        document.getElementById('transferBtn').innerHTML = '<i class="fas fa-spinner fa-spin"></i> 转移中...';
    });
})();
</script>

<style>
#fromClientDropdown .dropdown-item,
#toClientDropdown .dropdown-item {
    display: block;
    padding: 6px 12px;
    cursor: pointer;
    text-decoration: none;
    color: #333;
}
#fromClientDropdown .dropdown-item:hover,
#toClientDropdown .dropdown-item:hover {
    background-color: #f5f5f5;
}
#fromClientDropdown, #toClientDropdown {
    position: absolute;
    z-index: 1000;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 4px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}
</style>
SCRIPT;
}

